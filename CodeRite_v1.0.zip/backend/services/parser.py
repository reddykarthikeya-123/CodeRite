from fastapi import UploadFile, HTTPException
from pypdf import PdfReader
import pdfplumber
from docx import Document
from pptx import Presentation
import io
import pandas as pd
from PIL import Image
import pytesseract
from pdf2image import convert_from_bytes
import os
import base64

# Configure Tesseract path for Windows
tesseract_path = r"C:\Program Files\Tesseract-OCR\tesseract.exe"
if os.path.exists(tesseract_path):
    pytesseract.pytesseract.tesseract_cmd = tesseract_path

async def parse_file(file: UploadFile) -> dict:
    content = ""
    images = []
    filename = file.filename.lower()
    
    try:
        if filename.endswith(".pdf"):
            content, images = await _parse_pdf(file)
        elif filename.endswith(".docx"):
            content, images = await _parse_docx(file)
        elif filename.endswith(".pptx"):
            content, images = await _parse_pptx(file)
        elif filename.endswith((".txt", ".md", ".py", ".js", ".ts", ".json", ".html", ".css")):
            content = await _parse_text(file)
            images = []
        elif filename.endswith((".xlsx", ".xls", ".csv")):
            content = await _parse_excel(file)
            images = []
        else:
            raise HTTPException(status_code=400, detail="Unsupported file type")
            
        return {"text": content, "images": images}
    except Exception as e:
         import traceback
         err_trace = traceback.format_exc()
         raise HTTPException(status_code=500, detail=f"Error parsing file: {str(e)}\n\n{err_trace}")

async def _parse_pdf(file: UploadFile) -> tuple[str, list]:
    content = await file.read()
    
    text = ""
    
    # Text and Table extraction via pdfplumber (MIT Licensed, excellent layout parsing)
    with pdfplumber.open(io.BytesIO(content)) as pdf:
        for i, page in enumerate(pdf.pages):
            # 1. Extract raw text with spatial layout preservation
            # layout=True maintains visual columns and spaces
            page_text = page.extract_text(layout=True)
            if page_text:
                text += f"\n--- Page {i+1} Text ---\n{page_text}\n"
            
            # 2. Extract tables accurately as Markdown
            tables = page.extract_tables()
            if tables:
                text += f"\n--- Page {i+1} Tables ---\n"
                for table_idx, table in enumerate(tables):
                    text += f"Table {table_idx + 1}:\n"
                    for row in table:
                        # Clean up None values that pdfplumber returns for empty cells
                        cleaned_row = [str(cell).replace("\n", " ").strip() if cell is not None else "" for cell in row]
                        text += "| " + " | ".join(cleaned_row) + " |\n"
                    text += "\n"
    
    base64_images = []
    
    # OCR fallback/enhancement via pdf2image and pytesseract
    try:
        # Poppler is required for pdf2image. If not in PATH, this will fail gracefully.
        images = convert_from_bytes(content)
        for i, img in enumerate(images):
            # Base64 encode the image for Vision LLMs
            buffered = io.BytesIO()
            img.save(buffered, format="JPEG")
            img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
            base64_images.append(img_b64)
            
            # Only run OCR if page text seems sparse (e.g., scanned doc) to save time,
            # or just run it to catch embedded images. We'll add it if pypdf barely found anything.
            if len(text.strip()) < 100 * len(images): 
                ocr_text = pytesseract.image_to_string(img)
                text += f"\n--- OCR Page {i+1} ---\n" + ocr_text + "\n"
    except Exception as e:
        print(f"OCR/Vision warning on PDF: {e}")
        
    return text, base64_images

async def _parse_docx(file: UploadFile) -> tuple[str, list]:
    content = await file.read()
    doc = Document(io.BytesIO(content))
    text = "\n".join([para.text for para in doc.paragraphs])
    
    base64_images = []
    
    # Basic attempt to extract inline images from Docx
    try:
        for rel in doc.part.rels.values():
            if "image" in rel.target_ref:
                img_data = rel.target_part.blob
                img = Image.open(io.BytesIO(img_data))
                
                # Base64 encode
                buffered = io.BytesIO()
                if img.mode in ("RGBA", "P"): img = img.convert("RGB")
                img.save(buffered, format="JPEG")
                img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
                base64_images.append(img_b64)
                
                ocr_text = pytesseract.image_to_string(img)
                if ocr_text.strip():
                    text += f"\n--- Embedded Image OCR ---\n{ocr_text}\n"
    except Exception as e:
        print(f"OCR/Vision warning on Docx: {e}")
        
    return text, base64_images

async def _parse_pptx(file: UploadFile) -> tuple[str, list]:
    content = await file.read()
    prs = Presentation(io.BytesIO(content))
    text = ""
    base64_images = []
    
    for i, slide in enumerate(prs.slides):
        text += f"\n--- Slide {i+1} ---\n"
        
        # Extract text from shapes
        for shape in slide.shapes:
            if hasattr(shape, "text") and shape.text.strip():
                text += shape.text + "\n"
                
            # Extract images for Multi-Modal AI
            if getattr(shape, "shape_type", None) == 13: # 13 is msoPicture
                try:
                    img_bytes = shape.image.blob
                    img = Image.open(io.BytesIO(img_bytes))
                    
                    # Convert to Base64
                    buffered = io.BytesIO()
                    if img.mode in ("RGBA", "P"): img = img.convert("RGB")
                    img.save(buffered, format="JPEG")
                    img_b64 = base64.b64encode(buffered.getvalue()).decode("utf-8")
                    base64_images.append(img_b64)
                    
                    # OCR fallback
                    ocr_text = pytesseract.image_to_string(img)
                    if ocr_text.strip():
                        text += f"\n[Embedded Image OCR]: {ocr_text}\n"
                except Exception as e:
                    print(f"Failed to process image on slide {i+1}: {e}")
                    
        # Extract Speaker Notes
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame:
            notes = slide.notes_slide.notes_text_frame.text
            if notes.strip():
                text += f"\n[Speaker Notes]:\n{notes}\n"
                
    return text, base64_images

async def _parse_text(file: UploadFile) -> str:
    content = await file.read()
    return content.decode("utf-8")

async def _parse_excel(file: UploadFile) -> str:
    content = await file.read()
    filename = file.filename.lower()
    text = ""
    
    if filename.endswith(".csv"):
        df = pd.read_csv(io.BytesIO(content))
        text += f"--- CSV Data ---\n{df.to_csv(index=False)}\n"
    else:
        # Excel multi-sheet processing
        xls = pd.ExcelFile(io.BytesIO(content))
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)
            # Add sheet header and convert to CSV string for readable LLM parsing
            text += f"\n--- Excel Sheet: {sheet_name} ---\n"
            text += df.to_csv(index=False) + "\n"
            
    return text
